/*package com.company;

public class LexicalError extends Exception {
    private String line;
    private String message;
    public LexicalError(String line, String message) {
        this.line = line;
        this.message = message;
    }

    public String info() {
        return String.format("%s: %s", this.message, this.line);
    }
}*/