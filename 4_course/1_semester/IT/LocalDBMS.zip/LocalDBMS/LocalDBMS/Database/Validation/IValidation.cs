﻿
public interface IValidation
{
    void Apply(object value);
}