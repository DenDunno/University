﻿
public class StringValidation : IValidation
{
    public void Apply(object value)
    {
    }
}