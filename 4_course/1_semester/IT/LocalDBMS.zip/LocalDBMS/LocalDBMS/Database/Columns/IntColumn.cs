﻿
public class IntColumn : IColumn
{
    public void Validate()
    {
    }
}