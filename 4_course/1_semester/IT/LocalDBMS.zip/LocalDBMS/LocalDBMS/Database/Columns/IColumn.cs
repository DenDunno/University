﻿
public interface IColumn
{
    void Validate();
}